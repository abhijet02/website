'use client';

import { motion } from 'framer-motion';
import { FaGithub, FaLinkedin } from 'react-icons/fa';

export default function Home() {
  return (
    <main style={{minHeight:'100vh',background:'linear-gradient(135deg,#000,#0f172a,#000)',color:'#fff',padding:'40px'}}>
      <div style={{maxWidth:'1100px',margin:'0 auto',display:'grid',gridTemplateColumns:'1fr 1fr',gap:'40px',alignItems:'center'}}>

        <div>
          <h1 style={{fontSize:'48px',fontWeight:'bold'}}>Abhijeet Adhikary</h1>

          <h2 style={{fontSize:'22px',color:'#38bdf8',marginTop:'10px'}}>
            Lead System Engineer | DevOps | Cloud | Infrastructure | Security
          </h2>

          <p style={{marginTop:'20px',color:'#cbd5e1'}}>
            Lead System Engineer with 10+ years experience managing hybrid cloud,
            VMware environments (500+ VMs), Kubernetes clusters, and enterprise
            infrastructure with 99.9% uptime.
          </p>

          <div style={{marginTop:'30px',display:'flex',gap:'15px'}}>
            <a href="/cv.pdf" style={{background:'#2563eb',padding:'12px 20px',borderRadius:'10px'}}>
              Download CV
            </a>

            <a href="https://github.com/abhijet02" style={{border:'1px solid #334155',padding:'12px 20px',borderRadius:'10px'}}>
              GitHub
            </a>
          </div>

          <div style={{display:'flex',gap:'15px',marginTop:'20px',fontSize:'24px'}}>
            <FaGithub />
            <FaLinkedin />
          </div>
        </div>

        <motion.div
          animate={{ scale: [1, 1.05, 1] }}
          transition={{ repeat: Infinity, duration: 4 }}
          style={{display:'flex',justifyContent:'center'}}
        >
          <img
            src="/profile.jpg"
            alt="profile"
            style={{width:'260px',height:'260px',borderRadius:'50%',border:'4px solid #38bdf8',boxShadow:'0 0 30px rgba(56,189,248,0.6)'}}
          />
        </motion.div>

      </div>
    </main>
  );
}
