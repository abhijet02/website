export const metadata = {
  title: 'Abhijeet Portfolio',
  description: 'DevOps Engineer Portfolio',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
